# Number of workers
num_workers = 400

# Create a list of worker dictionaries dynamically, each with an id, gender, and salary
workers = [
    {'id': i, 'gender': 'female' if i % 2 == 0 else 'male', 'salary': 5000 + 500 * i % 15000}
    for i in range(num_workers)
]

# Loop through the workers to generate payment slips
for worker in workers:
    # Default employee level
    employee_level = 'Not Assigned'

    # Conditional checks for assigning employee level based on salary and gender
    if 10000 < worker['salary'] < 20000:
        employee_level = 'A1'
    if 7500 < worker['salary'] < 30000 and worker['gender'] == 'female':
        employee_level = 'A5-F'
    
    # Generate and print the payment slip for the worker
    print(f"Payment Slip for Worker ID {worker['id']}:")
    print(f"Gender: {worker['gender']}")
    print(f"Salary: ${worker['salary']}")
    print(f"Employee Level: {employee_level}")
    print("-" * 40)
