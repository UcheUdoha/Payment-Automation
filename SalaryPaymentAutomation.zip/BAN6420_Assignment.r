# Set the number of workers
num_workers <- 400

# Create a data frame to store worker data with IDs, gender, and salary
workers <- data.frame(
  id = 1:num_workers,
  gender = rep(c("female", "male"), each = 2, length.out = num_workers),
  salary = 5000 + (500 * (1:num_workers) %% 15000)
)

# Define a vector to store employee levels
employee_level <- vector("character", length = num_workers)

# Loop through the workers to generate payment slips
for (i in 1:num_workers) {
  # Default employee level is Not Assigned
  employee_level[i] <- "Not Assigned"
  
  # Conditional checks for assigning employee level based on salary and gender
  if (workers$salary[i] > 10000 & workers$salary[i] < 20000) {
    employee_level[i] <- "A1"
  }
  if (workers$salary[i] > 7500 & workers$salary[i] < 30000 & workers$gender[i] == "female") {
    employee_level[i] <- "A5-F"
  }
  
  # Print the payment slip for the worker
  cat(sprintf("Payment Slip for Worker ID %d:\n", workers$id[i]))
  cat(sprintf("Gender: %s\n", workers$gender[i]))
  cat(sprintf("Salary: $%d\n", workers$salary[i]))
  cat(sprintf("Employee Level: %s\n", employee_level[i]))
  cat(rep("-", 40), "\n")
}

# Optionally, you could add the employee_level to the workers data frame
workers$employee_level <- employee_level
